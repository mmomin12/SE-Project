<?php 
include 'config.php';

	session_start();
	


if (!empty($_POST)){
	$first_name = $_POST['Fname'];
	$last_name = $_POST['Lname'];
	$sex = $_POST['sex'];
	$type = $_POST['semesterDivide'];
	$classarea = $_POST['ClassArea'];
	$description= $conn->real_escape_string($_POST['description']);
	
	$sql = "INSERT INTO profile (firstname, lastname, sex, type, classarea, description) VALUES ('".$first_name."','".$last_name."','".$sex."','".$type."','".$classarea."','".$description."')";
	
	if ($conn->query($sql) === TRUE) {
		
		$sql = "select * from users where userid='".$_SESSION['userid']."'";
	
		$res=$conn->query($sql);
	
		while($row = $res->fetch_assoc()) {
			if($row["profile"]==0){
				$conn->query("UPDATE users SET profile='1' WHERE userid='".$_SESSION['userid']."' AND profile='0'");
					$_SESSION['profile'] = 1;
					header("Location: http://www.gsustudymatch.com/searchpartner.php");
					exit();
			}
			else{
				header("Location: http://www.gsustudymatch.com/searchpartner.php");
				exit();
			}
		
		}	
		

	}
	else{
		echo $conn->error;
	}
	
	
}else{
	header("Location: http://www.gsustudymatch.com/profile.php");
	exit();
}


?>
	